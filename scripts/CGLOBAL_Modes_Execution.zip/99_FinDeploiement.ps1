﻿#Requires -Version 5.1
#Requires -RunAsAdministrator
[CmdletBinding()]
param([ValidateSet('Interactive','Prevalidated','Silent')][string]$ExecutionMode='Interactive',[string]$SessionFile)
$ErrorActionPreference='Stop';Import-Module 'C:\_CGLOBAL\PS1\CGLOBAL.Common.psm1' -Force;. 'C:\_CGLOBAL\PS1\CGLOBAL.Session.ps1'
$LogFile=Get-CGlobalLogFile -ScriptPath $PSCommandPath;Initialize-CGlobalLog -LogFile $LogFile
try{
 $s=Get-CGlobalSession $SessionFile;$finish=Get-CGlobalSessionValue $s 'DeploymentModeAction' 'Ask';$wu=Get-CGlobalSessionValue $s 'WindowsUpdateAction' 'Ask'
 if($ExecutionMode -eq 'Interactive' -or $finish -eq 'Ask'){$c=Show-CGlobalPopup -Title 'Mode déploiement' -Message 'Désactiver le mode déploiement et réactiver Windows Update ?' -Buttons YesNo -Icon Question;$finish=if($c -eq 'Yes'){'Disable'}else{'Keep'}}
 if($finish -ne 'Disable'){Write-Log 'Mode déploiement conservé' 'INFO';exit 0}
 powercfg.exe /change monitor-timeout-ac 5|Out-Null;powercfg.exe /change standby-timeout-ac 0|Out-Null;powercfg.exe /change monitor-timeout-dc 5|Out-Null;powercfg.exe /change standby-timeout-dc 30|Out-Null
 $k='HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate';$au="$k\AU";foreach($n in 'NoAutoUpdate','NoAutoRebootWithLoggedOnUsers'){Remove-ItemProperty $au $n -ErrorAction SilentlyContinue};foreach($n in 'AllowOptionalContent','NoAutoUpdate','DisableWindowsUpdateAccess','SetDisableUXWUAccess','DoNotConnectToWindowsUpdateInternetLocations'){Remove-ItemProperty $k $n -ErrorAction SilentlyContinue};gpupdate.exe /target:computer /force|Out-Null
 if($ExecutionMode -eq 'Interactive' -or $wu -eq 'Ask'){$c=Show-CGlobalPopup -Title 'Windows Update' -Message 'Rechercher et installer immédiatement les mises à jour ?' -Buttons YesNo -Icon Question;$wu=if($c -eq 'Yes'){'Launch'}else{'Skip'}}
 if($wu -eq 'Launch'){$u="$env:SystemRoot\System32\UsoClient.exe";if(Test-Path $u){Start-Process $u StartScan -WindowStyle Hidden;Start-Sleep 3;Start-Process $u StartDownload -WindowStyle Hidden;Start-Sleep 3;Start-Process $u StartInstall -WindowStyle Hidden}}
 Write-Log 'Mode déploiement désactivé' 'OK';if($ExecutionMode -eq 'Interactive'){Show-CGlobalPopup -Title 'Fin du déploiement' -Message 'Mode déploiement désactivé.' -Buttons OK -Icon Information|Out-Null};exit 0
}catch{Write-Log $_.Exception.Message 'ERROR';exit 1}
