﻿#Requires -Version 5.1
#Requires -RunAsAdministrator
[CmdletBinding()]
param([ValidateSet('Interactive','Prevalidated','Silent')][string]$ExecutionMode='Interactive',[string]$SessionFile)
$ErrorActionPreference='Stop'; Import-Module 'C:\_CGLOBAL\PS1\CGLOBAL.Common.psm1' -Force; . 'C:\_CGLOBAL\PS1\CGLOBAL.Session.ps1'
$LogFile=Get-CGlobalLogFile -ScriptPath $PSCommandPath; Initialize-CGlobalLog -LogFile $LogFile
try{
 Write-Log '=== DÉSINSTALLATION ONEDRIVE ==='
 $appx=@(Get-AppxPackage -AllUsers -Name '*OneDrive*' -ErrorAction SilentlyContinue)
 $prov=@(Get-AppxProvisionedPackage -Online -ErrorAction SilentlyContinue|Where-Object DisplayName -like '*OneDrive*')
 $exe=@("$env:LOCALAPPDATA\Microsoft\OneDrive\OneDrive.exe","$env:SystemRoot\SysWOW64\OneDriveSetup.exe","$env:SystemRoot\System32\OneDriveSetup.exe")|Where-Object{Test-Path $_}|Select-Object -First 1
 $regs=@('HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*','HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*','HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*')
 $reg=@($regs|ForEach-Object{Get-ItemProperty $_ -ErrorAction SilentlyContinue}|Where-Object DisplayName -like '*OneDrive*')
 if($appx.Count+$prov.Count+$reg.Count -eq 0 -and -not $exe){Write-Log 'OneDrive non détecté' 'OK';exit 0}
 $s=Get-CGlobalSession $SessionFile;$action=Get-CGlobalSessionValue $s 'OneDriveAction' 'Ask'
 if($ExecutionMode -eq 'Interactive' -or $action -eq 'Ask'){$c=Show-CGlobalPopup -Title 'Désinstallation OneDrive' -Message "OneDrive est installé.`n`nVoulez-vous le désinstaller et le bloquer pour les futurs profils ?" -Buttons YesNo -Icon Exclamation;$action=if($c -eq 'Yes'){'Uninstall'}else{'Keep'}}
 if($action -ne 'Uninstall'){Write-Log 'OneDrive conservé' 'WARN';exit 0}
 Stop-Process -Name OneDrive -Force -ErrorAction SilentlyContinue
 foreach($r in $reg){if($r.UninstallString){try{$cmd=$r.UninstallString;if($cmd -match '^"([^"]+)"\s*(.*)$'){$x=$Matches[1];$a=$Matches[2]}else{$parts=$cmd -split '\s+',2;$x=$parts[0];$a=if($parts.Count -gt 1){$parts[1]}else{''}};Start-Process $x -ArgumentList $a -Wait -ErrorAction Stop|Out-Null}catch{Write-Log $_.Exception.Message 'WARN'}}}
 if($exe -and (Test-Path $exe)){Start-Process $exe -ArgumentList '/uninstall' -Wait -ErrorAction SilentlyContinue|Out-Null}
 foreach($p in $appx){Remove-AppxPackage -Package $p.PackageFullName -AllUsers -ErrorAction SilentlyContinue}
 foreach($p in $prov){Remove-AppxProvisionedPackage -Online -PackageName $p.PackageName -ErrorAction SilentlyContinue|Out-Null}
 $policy='HKLM:\SOFTWARE\Policies\Microsoft\Windows\OneDrive';New-Item $policy -Force|Out-Null;New-ItemProperty $policy DisableFileSyncNGSC -PropertyType DWord -Value 1 -Force|Out-Null
 Write-Log 'OneDrive désinstallé et bloqué' 'OK';exit 0
}catch{Write-Log $_.Exception.Message 'ERROR';if($ExecutionMode -eq 'Interactive'){Show-CGlobalPopup -Title 'Erreur OneDrive' -Message $_.Exception.Message -Buttons OK -Icon Stop|Out-Null};exit 1}
