﻿#Requires -Version 5.1
#Requires -RunAsAdministrator
[CmdletBinding()]
param([ValidateSet('Interactive','Prevalidated','Silent')][string]$ExecutionMode='Interactive',[string]$SessionFile)
$ErrorActionPreference='Stop'
Import-Module 'C:\_CGLOBAL\PS1\CGLOBAL.Common.psm1' -Force
. 'C:\_CGLOBAL\PS1\CGLOBAL.Session.ps1'
$LogFile=Get-CGlobalLogFile -ScriptPath $PSCommandPath; Initialize-CGlobalLog -LogFile $LogFile
function Get-OfficeInstalls {
 $paths=@('HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*','HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*','HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*')
 $r=foreach($p in $paths){Get-ItemProperty $p -ErrorAction SilentlyContinue|Where-Object{$_.DisplayName -match 'Microsoft (Office|365|Project|Visio|OneNote)' -and $_.DisplayName -notmatch 'Update|MUI|Redistributable|Runtime|Licensing|Proofing|Help|Language|Font|Theme|Visual Studio' -and $_.UninstallString}|ForEach-Object{[pscustomobject]@{Name=$_.DisplayName;Version=$_.DisplayVersion;Command=$_.UninstallString}}}
 @($r|Sort-Object Name,Command -Unique)
}
function Invoke-Uninstall($item){
 $u=[string]$item.Command
 if($u -match '(?i)msiexec' -and $u -match '\{[0-9A-Fa-f-]+\}'){$p=Start-Process msiexec.exe -ArgumentList "/x $($Matches[0]) /quiet /norestart" -Wait -PassThru;return $p.ExitCode}
 if($u -match '^"([^"]+)"\s*(.*)$'){$exe=$Matches[1];$args=$Matches[2]} elseif($u -match '^(\S+\.exe)\s*(.*)$'){$exe=$Matches[1];$args=$Matches[2]} else{throw "Commande de désinstallation non reconnue : $u"}
 if($args -notmatch '(?i)quiet|silent|DisplayLevel=False'){$args+=' DisplayLevel=False'}
 $p=Start-Process -FilePath $exe -ArgumentList $args -Wait -PassThru; $p.ExitCode
}
try{
 Write-Log '=== DÉSINSTALLATION OFFICE / ONENOTE ==='
 $items=@(Get-OfficeInstalls); if($items.Count -eq 0){Write-Log 'Aucun produit Office / OneNote détecté' 'OK';exit 0}
 $s=Get-CGlobalSession $SessionFile; $action=Get-CGlobalSessionValue $s 'OfficeAction' 'Ask'
 if($ExecutionMode -eq 'Interactive' -or $action -eq 'Ask'){$list=($items|ForEach-Object{"- $($_.Name) $($_.Version)"}) -join "`n";$c=Show-CGlobalPopup -Title 'Désinstallation Office / OneNote' -Message "Produits détectés :`n`n$list`n`nVoulez-vous tous les désinstaller ?" -Buttons YesNo -Icon Exclamation;$action=if($c -eq 'Yes'){'Uninstall'}else{'Keep'}}
 if($action -ne 'Uninstall'){Write-Log 'Produits Office / OneNote conservés' 'WARN';exit 0}
 foreach($i in $items){try{$code=Invoke-Uninstall $i;if($code -in 0,3010){Write-Log "$($i.Name) désinstallé (code $code)" 'OK'}else{Write-Log "$($i.Name) : code $code" 'WARN'}}catch{Write-Log "Échec $($i.Name) : $($_.Exception.Message)" 'ERROR'}}
 exit 0
}catch{Write-Log $_.Exception.Message 'ERROR';exit 1}
