﻿#Requires -Version 5.1
#Requires -RunAsAdministrator
[CmdletBinding()]
param([ValidateSet('Interactive','Prevalidated','Silent')][string]$ExecutionMode='Interactive',[string]$SessionFile)
$ErrorActionPreference='Stop';Import-Module 'C:\_CGLOBAL\PS1\CGLOBAL.Common.psm1' -Force;. 'C:\_CGLOBAL\PS1\CGLOBAL.Session.ps1'
$LogFile=Get-CGlobalLogFile -ScriptPath $PSCommandPath;Initialize-CGlobalLog -LogFile $LogFile;$reboot=$false
function Run([string]$f,[string[]]$a){Write-Log("Commande : $f "+($a-join' '));$o=&$f @a 2>&1;$c=$LASTEXITCODE;$o|ForEach-Object{Write-Log $_.ToString()};$c}
try{
 $m=(Get-CimInstance Win32_ComputerSystem).Manufacturer;$kind=if($m -match 'Lenovo'){'LENOVO'}elseif($m -match 'Dell'){'DELL'}else{'OTHER'};Write-Log "Constructeur : $m"
 if($kind -eq 'OTHER'){Write-Log 'Constructeur non pris en charge' 'WARN';exit 0}
 $s=Get-CGlobalSession $SessionFile;$mode=Get-CGlobalSessionValue $s 'ManufacturerUpdateMode' 'Ask'
 if($ExecutionMode -eq 'Interactive' -or $mode -eq 'Ask'){$c=Show-CGlobalPopup -Title 'Mises à jour constructeur' -Message "Oui = toutes les mises à jour, BIOS/firmware inclus`nNon = sans redémarrage forcé`nAnnuler = ignorer ce script" -Buttons YesNoCancel -Icon Question;$mode=if($c -eq 'Yes'){'ALL'}elseif($c -eq 'No'){'NO_FORCED_REBOOT'}else{'SKIP'}}
 if($mode -eq 'SKIP'){Write-Log 'Mises à jour constructeur ignorées' 'WARN';exit 0}
 if(-not(Get-Command winget.exe -ErrorAction SilentlyContinue)){throw 'winget.exe introuvable'}
 if($kind -eq 'LENOVO'){
  $tvsu=@('C:\Program Files (x86)\Lenovo\System Update\tvsu.exe','C:\Program Files\Lenovo\System Update\tvsu.exe')|Where-Object{Test-Path $_}|Select-Object -First 1
  if(-not$tvsu){winget install --id Lenovo.SystemUpdate -e --silent --accept-package-agreements --accept-source-agreements --disable-interactivity|Out-Null;$tvsu=@('C:\Program Files (x86)\Lenovo\System Update\tvsu.exe','C:\Program Files\Lenovo\System Update\tvsu.exe')|Where-Object{Test-Path $_}|Select-Object -First 1}
  if(-not$tvsu){throw 'Lenovo System Update introuvable'}
  $args=if($mode -eq 'ALL'){@('/CM','-search','A','-action','INSTALL','-includerebootpackages','1,3,4,5','-nolicense','-noicon')}else{@('/CM','-search','A','-action','INSTALL','-includerebootpackages','1,3','-noreboot','-nolicense','-noicon')};$code=Run $tvsu $args
 }else{
  $dcu=@('C:\Program Files\Dell\CommandUpdate\dcu-cli.exe','C:\Program Files (x86)\Dell\CommandUpdate\dcu-cli.exe')|Where-Object{Test-Path $_}|Select-Object -First 1
  if(-not$dcu){winget install --id Dell.CommandUpdate -e --silent --accept-package-agreements --accept-source-agreements --disable-interactivity|Out-Null;$dcu=@('C:\Program Files\Dell\CommandUpdate\dcu-cli.exe','C:\Program Files (x86)\Dell\CommandUpdate\dcu-cli.exe')|Where-Object{Test-Path $_}|Select-Object -First 1}
  if(-not$dcu){throw 'Dell Command Update introuvable'};$rb=if($mode -eq 'ALL'){'-reboot=enable'}else{'-reboot=disable'};$code=Run $dcu @('/applyUpdates','-updateType=bios,firmware,driver,application,others','-silent',$rb,'-outputLog=C:\_CGLOBAL\Logs\DellCommandUpdate.log')
 }
 if($code -in 1,3010){$reboot=$true};if($code -notin 0,1,3010,500){throw "Code constructeur inattendu : $code"};if($reboot){Write-Log 'Redémarrage requis' 'WARN';if($ExecutionMode -eq 'Interactive'){Show-CGlobalPopup -Title 'Redémarrage requis' -Message 'Les mises à jour constructeur nécessitent un redémarrage.' -Buttons OK -Icon Exclamation|Out-Null}}
 Write-Log 'Mises à jour constructeur terminées' 'OK';exit 0
}catch{Write-Log $_.Exception.Message 'ERROR';exit 1}
