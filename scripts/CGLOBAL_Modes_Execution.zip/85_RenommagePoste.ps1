﻿#Requires -Version 5.1
#Requires -RunAsAdministrator
[CmdletBinding()]
param([ValidateSet('Interactive','Prevalidated','Silent')][string]$ExecutionMode='Interactive',[string]$SessionFile)
$ErrorActionPreference='Stop';Import-Module 'C:\_CGLOBAL\PS1\CGLOBAL.Common.psm1' -Force;. 'C:\_CGLOBAL\PS1\CGLOBAL.Session.ps1'
$LogFile=Get-CGlobalLogFile -ScriptPath $PSCommandPath;Initialize-CGlobalLog -LogFile $LogFile
function Valid([string]$n){if([string]::IsNullOrWhiteSpace($n)){return'Nom vide'};$n=$n.Trim();if($n.Length -gt 15){return'Plus de 15 caractères'};if($n -notmatch '^[A-Za-z0-9-]+$'){return'Caractères interdits'};if($n -match '^-|-$'){return'Trait d union en début ou fin'};if($n -match '^\d+$'){return'Nom entièrement numérique'};if($n -ieq $env:COMPUTERNAME){return'Nom identique au nom actuel'};return $null}
try{
 $s=Get-CGlobalSession $SessionFile;$action=Get-CGlobalSessionValue $s 'RenameAction' 'Ask';$new=Get-CGlobalSessionValue $s 'ComputerName' $null
 if($ExecutionMode -eq 'Interactive' -or $action -eq 'Ask'){$c=Show-CGlobalPopup -Title 'Renommage du poste' -Message "Nom actuel : $env:COMPUTERNAME`n`nVoulez-vous le modifier ?" -Buttons YesNoCancel -Icon Question;if($c -ne 'Yes'){exit 0};$action='Rename';$new=Show-CGlobalInputBox -Title 'Renommage du poste' -Message 'Saisissez le nouveau nom (15 caractères maximum).' -DefaultText $env:COMPUTERNAME}
 if($action -ne 'Rename'){Write-Log 'Renommage ignoré' 'OK';exit 0};$e=Valid $new;if($e){throw "Nom de poste invalide : $e"};Rename-Computer -NewName $new.Trim() -Force;Write-Log "Poste renommé en $new. Redémarrage requis." 'OK';if($ExecutionMode -eq 'Interactive'){Show-CGlobalPopup -Title 'Redémarrage requis' -Message "Le poste a été renommé en '$new'." -Buttons OK -Icon Exclamation|Out-Null};exit 0
}catch{Write-Log $_.Exception.Message 'ERROR';if($ExecutionMode -eq 'Interactive'){Show-CGlobalPopup -Title 'Échec du renommage' -Message $_.Exception.Message -Buttons OK -Icon Stop|Out-Null};exit 1}
