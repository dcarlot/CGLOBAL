﻿CGLOBAL - lot modes Interactif / Prévalidé / Silencieux

Fichiers à copier dans C:\_CGLOBAL\PS1 et dans le dossier PS1 de la clé :
- Run_Selective.ps1
- CGLOBAL.Session.ps1
- 14_DesinstallationOffice.ps1
- 17_DesinstallationOneDrive.ps1
- 19_MisesAJourConstructeur.ps1
- 85_RenommagePoste.ps1
- 90_VerificationMotDePasseCompteLocal.ps1
- 99_FinDeploiement.ps1

Le mot de passe prévalidé est chiffré par DPAPI via ConvertFrom-SecureString et le fichier de session temporaire est supprimé en fin d'exécution.
Le mode Silencieux utilise des valeurs prudentes et non destructives.
