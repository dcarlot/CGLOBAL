﻿#Requires -Version 5.1
Set-StrictMode -Version 2.0
function Get-CGlobalSession {
    param([string]$SessionFile)
    if ([string]::IsNullOrWhiteSpace($SessionFile) -or -not (Test-Path -LiteralPath $SessionFile)) { return $null }
    try { return (Get-Content -LiteralPath $SessionFile -Raw -Encoding UTF8 | ConvertFrom-Json) }
    catch { throw "Fichier de session CGLOBAL invalide : $($_.Exception.Message)" }
}
function Get-CGlobalSessionValue {
    param($Session,[string]$Name,$Default=$null)
    if ($null -eq $Session) { return $Default }
    $p=$Session.PSObject.Properties[$Name]
    if ($null -eq $p) { return $Default }
    return $p.Value
}
